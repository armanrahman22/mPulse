
// jQuery(document).ready(function() {
//     		alert(1);
//     		alert(jQuery(".outputControl").length);
//     		alert(2);
// 			jQuery(".outputControl").click(function(){
// 				alert(1);
// 				alert($$(this).data('pin'));
// 				alert($$(this).data('val'));
// 			});
//     	});
function controlOutput(var pin, var val){
	alert(pin);
}

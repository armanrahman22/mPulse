M-PULSE-Kiosk
=============

Code repository for the m-pulse code that resides on the kiosk "clients"